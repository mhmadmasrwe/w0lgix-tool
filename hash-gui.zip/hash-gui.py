from Tkinter import *
import tkMessageBox

a = raw_input('enter hex: ')

#if Checkbutton.get():
a1 = a.decode('hex')

def crack():
    
	Label(window,fg="black",bg="red").place(x=480,y=60)
    
	tkMessageBox.showinfo("Rezlut", a1)




window = Tk()

image = PhotoImage(file="Untitled1.png")
background = Label(window, image=image).pack(side="bottom",fill="both",expand="yes")

window.geometry("800x400")
window.title("Crack Hash v1.1")
window.configure(bg="white")
Label(window, text="Hash:",fg="black",bg="red").place(x=380,y=60)


v = StringVar(window, value=a)
a1 = a.decode('hex')
label1=Entry(window,bg="black",width=50,fg="white",textvariable=v).place(x=190 , y=80)


Checkbutton(window ,text="Hex" ,bg="white",fg="black",activebackground="pink").place(x=360,y=120)
Checkbutton(window, text="md5" ,bg="white",fg="black",activebackground="pink").place(x=470,y=120)
Checkbutton(window, text="sha1" ,bg="white",fg="black",activebackground="pink").place(x=250 ,y=120)

	



window = Button(text="Crack",relief=GROOVE , cursor="spider", fg="red" , bg="blue" , width=7 , height=1 , bd=5 , activebackground="green" , activeforeground="white"  ,command=crack).place(x=350 , y=240)


mainloop()




