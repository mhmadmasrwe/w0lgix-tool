#!/usr/bin/py

script_v = "0.2"

vulnerabilities = ["InBoundio", "Symposium", "RevSliderDEF", "RevSliderDOW", "CRCOForm", "GVForm", "SMBackup", "HBDown", "MemphisDown", "WPTFD", "RecentBack", "SIMPIMMan", "WPCand", "CPImgst", "WPCom", "HT5VID", "HistCol", "MIOFtp", "ASpoSe", "ajaxStore", "GooMp3", "DBBackup", "JDownloads", "Fabrik", "Media", "CRForm", "Maian15", "RokDown", "SWUp", "JFancy", "ArtUp", "DentroVideo", "Efup", "SMDL", "DRGDROP", "DRSQLI", "CMSRFI", "SMPSLIDESHOW", "PAGEADVERTS", "HPADVERT", "CLADVERTS"]