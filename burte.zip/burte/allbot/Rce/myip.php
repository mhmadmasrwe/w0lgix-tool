<?php 
#r00t-Pwn
#https://www.facebook.com/Ali.Phtml
set_time_limit(0);
error_reporting(0);
echo "################ Joomla Gabber By Ip Range###############\n\n";
echo "Coded By : r00t-Pwn \n\n";
echo "Follow Me In FaceBook : https://www.facebook.com/Ali.Phtml\n\n";
echo "################# Let's Start Hunting #####################\n\n";
echo "Server Target IP : ";
$ip=trim(fgets(STDIN,1024));
$ip = explode('.',$ip);
$ip = $ip[0].'.'.$ip[1].'.'.$ip[2].'.';
for($i=0;$i <= 255;$i++)
{
$sites = array_map("site", bing("ip:$ip.$i Powered By Joomla"));
$un=array_unique($sites);
echo "[+] Scanning -> ", $ip.$i, ""."\n";
echo "Found : ".count($sites)." sites\n\n";
foreach($un as $pok){
$host=findit($file,"DB_HOST', '","');");
$db=findit($file,"DB_NAME', '","');");
$us=findit($file,"DB_USER', '","');");
$pw=findit($file,"DB_PASSWORD', '","');");
$bda="http://$pok";
	
	$save=fopen('Joomla.txt','ab');
	fwrite($save,"$bda/\r\n");
	}
	
}
function findit($mytext,$starttag,$endtag) {
 $posLeft  = stripos($mytext,$starttag)+strlen($starttag);
 $posRight = stripos($mytext,$endtag,$posLeft+1);
 return  substr($mytext,$posLeft,$posRight-$posLeft);
}
function site($link){
return str_replace("","",parse_url($link, PHP_URL_HOST));
}
function bing($what){
for($i = 1; $i <= 2000; $i += 10){
$ch = curl_init();
curl_setopt ($ch, CURLOPT_URL, "http://www.bing.com/search?q=".urlencode($what)."&first=".$i."&FORM=PERE");
curl_setopt ($ch, CURLOPT_USERAGENT, "msnbot/1.0 (http://search.msn.com/msnbot.htm)");
curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_COOKIEFILE,getcwd().'/cookie.txt');
curl_setopt ($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, 1);
$data = curl_exec($ch);
preg_match_all('#;a=(.*?)" h="#',$data, $links);
foreach($links[1] as $link){
$allLinks[] = $link;
}
if(!preg_match('#"sw_next"#',$data)) break;
}

if(!empty($allLinks) && is_array($allLinks)){
return array_unique(array_map("urldecode", $allLinks));
}
}
?>