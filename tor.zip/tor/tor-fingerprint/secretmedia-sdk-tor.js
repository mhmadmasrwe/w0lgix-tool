/* Test Tor 2.3 */
document.write('<div id="tester23" style="display:none">advertisement</div>');
