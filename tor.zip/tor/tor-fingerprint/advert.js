document.write('<div id="tester" style="display:none">advertisement</div>');
